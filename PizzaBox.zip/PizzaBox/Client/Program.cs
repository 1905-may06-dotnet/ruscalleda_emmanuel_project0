﻿// Client or Presentation or UI layer 

using System;
using Data;
using Domain;
using Testing;
using Data.DataModel;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using System.Linq;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;



namespace Client
{
    class Program
    {

        static void Main(string[] args)
        {

            /*
            // values for testing 
            string email = "er@gmail.com";
            int orderAddress = 1;
            */

            string email = ClassDomain.LogIn();
            Thread.Sleep(2000);
            Console.Clear();
            // ****************************
            int userAddres = ClassDomain.AddUserAddress(email);
            Thread.Sleep(2000);
            Console.Clear();
            // ****************************
            // >>> need method to select card number
            // >>> need method to select store location 



            string cardNumber = "1111-1111-1111-1111";
            int storeLocation = 1;
            DateTime orderDateTime = DateTime.Now;
            string orderDate = orderDateTime.ToString("yyyy/MM/dd");
            string orderTime = orderDateTime.ToString("HH:mm:ss"); // 24-hrs format 

            // values for testing 
            int qtyInOrder = 25;
            double totalInOrder = 8.99 * qtyInOrder;

            bool addMore = true;


            while (addMore)
            {
                ClassDomain.MakeAnOrder(qtyInOrder, totalInOrder);

            }






        } // end of: Main class 

    } // end of: Program class 

} // end of: Client namespace 