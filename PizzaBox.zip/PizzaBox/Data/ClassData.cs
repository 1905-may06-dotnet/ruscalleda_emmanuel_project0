﻿// Data layer 
using System;

namespace Data
{
    public class ClassData
    {
        public string myStr = "this is ClassData";
        

      

    }
}
