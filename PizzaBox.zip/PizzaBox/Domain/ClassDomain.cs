﻿// Domain or Business layer 
// classes and logics will be here 
using System;
using System.Collections.Generic;
using Data.DataModel;
using Domain;
using System.Linq;
using System.Diagnostics;
using System.Threading;





namespace Domain
{
    public class ClassDomain
    {

        #region LogIn

        public static string LogIn()
        {
            PizzaBoxContex PBContex = new PizzaBoxContex();
            string output = "";
            bool loginsuccessful = true;
            do
            {
                Console.WriteLine("Welcome to PizzaBox!");
                Console.WriteLine("[1] SIGN IN \n[2] new user \n[99] close application");
                Console.Write("Choose between the above options: \t");
                int intLogIn = Convert.ToInt32(Console.ReadLine());

                // existing user - sign in 
                if (1 == intLogIn)
                {
                    string emailInput = "";
                    string passwordInput = "";
                    bool foundFlag;
                    do
                    {
                        foundFlag = true;
                        Console.Write("Email: \t");
                        emailInput = Console.ReadLine();
                        emailInput = emailInput.Trim();
                        // check if input email is on database 
                        try
                        {
                            PBContex.UserName.Where<UserName>(u => u.Email == emailInput).First<UserName>();
                        }
                        catch
                        {
                            if (emailInput.Equals("99"))
                            {
                                Environment.Exit(0);
                            }
                            Console.WriteLine("\n\n\nUser not found. Try again. \nTo exit enter [99]. \n\n\n");
                            foundFlag = false;
                        }
                    } while (foundFlag == false);


                    int passwordAttempts = 0;
                    do
                    {
                        foundFlag = true;
                        Console.Write("Password: \t");
                        passwordInput = Console.ReadLine();
                        passwordInput = passwordInput.Trim();
                        // check if password match email  
                        try
                        {
                            PBContex.UserAccess.Where<UserAccess>(u => u.Email == emailInput && u.Password == passwordInput).First<UserAccess>();
                        }
                        catch
                        {
                            if (passwordInput.Equals("99"))
                            {
                                Environment.Exit(0);
                            }
                            Console.WriteLine("\n\n\nIncorrect password. Try again. \nTo exit enter [99]. \n\n\n");
                            passwordAttempts = passwordAttempts + 1;
                            if (passwordAttempts >= 3)
                            {
                                Console.WriteLine("Exceeded the allowed attempts.");
                                Environment.Exit(0);
                            }
                            foundFlag = false;
                        }
                    } while (foundFlag == false);

                    Console.WriteLine("\n\n\nSign In successful. \n\n\n");
                    output = emailInput;
                }

                // new user - sign up 
                else if (2 == intLogIn)
                {
                    string emailInput1 = "";
                    string emailInput2 = "";
                    bool exiteWhile;

                    do
                    {
                        exiteWhile = false;
                        Console.Write("Email: \t");
                        emailInput1 = Console.ReadLine();
                        emailInput1 = emailInput1.Trim();
                        emailInput2 = "";
                        if (emailInput1.Equals("99") == false)
                        {
                            Console.Write("Re-enter Email: \t");
                            emailInput2 = Console.ReadLine();
                            emailInput2 = emailInput2.Trim();
                        }

                        // check if email is not already in database 
                        if (emailInput1.Equals(emailInput2) && emailInput1.Equals("") == false)
                        {
                            exiteWhile = false;
                            try
                            {
                                PBContex.UserName.Where<UserName>(u => u.Email == emailInput1).First<UserName>();
                            }
                            catch
                            {
                                // if error is catch then the input email is not in database 
                                exiteWhile = true;
                            }
                            finally
                            {
                                if (exiteWhile == false)
                                {
                                    Console.WriteLine("\n\n\nEmail entry is already in use. Try again. \nTo exit enter [99]. \n\n\n");
                                }
                            }
                        }
                        else if (emailInput1.Equals("99"))
                        {
                            Environment.Exit(0);
                        }
                        else
                        {
                            Console.WriteLine("\n\n\nEmails entry does not match or are empty. Try again. \nTo exit enter [99]. \n\n\n");
                            exiteWhile = false;
                        }
                    } while (exiteWhile == false);

                    string passwordInput1 = "";
                    string passwordInput2 = "";
                    string firstName = "";
                    string lastName = "";
                    string phone = "";
                    // check passwords to be equal 
                    do
                    {
                        exiteWhile = false;
                        Console.Write("Password: \t");
                        passwordInput1 = Console.ReadLine();
                        passwordInput1 = passwordInput1.Trim();
                        passwordInput2 = "";
                        if (passwordInput1.Equals("99") == false)
                        {
                            Console.Write("Re-enter Password: \t");
                            passwordInput2 = Console.ReadLine();
                            passwordInput2 = passwordInput2.Trim();
                        }

                        if (passwordInput1.Equals(passwordInput2) && passwordInput1.Equals("") == false)
                        {
                            Console.Write("First Name: \t");
                            firstName = Console.ReadLine();
                            firstName = firstName.Trim();

                            Console.Write("Last Name: \t");
                            lastName = Console.ReadLine();
                            lastName = lastName.Trim();

                            Console.Write("Phone [xxx-xxx-xxxx]: \t");
                            phone = Console.ReadLine();
                            phone = phone.Trim();

                            exiteWhile = true;
                        }
                        else if (passwordInput1.Equals("99"))
                        {
                            Environment.Exit(0);
                        }
                        else
                        {
                            Console.WriteLine("\n\n\nPasswords entry does not match or are empty. Try again. \nTo exit enter [99]. \n\n\n");
                            exiteWhile = false;
                        }
                    } while (exiteWhile == false);


                    UserName newUserName = new UserName();
                    newUserName.Email = emailInput1;
                    newUserName.FirstName = firstName;
                    newUserName.LastName = lastName;
                    newUserName.Phone = phone;
                    PBContex.UserName.Add(newUserName);
                    PBContex.SaveChanges();

                    UserAccess newUserAccess = new UserAccess();
                    newUserAccess.Email = emailInput1;
                    newUserAccess.Password = passwordInput1;
                    PBContex.UserAccess.Add(newUserAccess);
                    PBContex.SaveChanges();

                    Console.WriteLine("\n\n\nSign Up successful. \n\n\n");

                    output = emailInput1;
                }
                else if (99 == intLogIn)
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine($"\n\n\nInput [{intLogIn}] is not supported. Try again.\n\n\n");
                    loginsuccessful = false;
                }
            } while (false == loginsuccessful);

            return output;

        } // end of: LogIn class 
        #endregion


        #region AddUserAddress
        // ------------- > need to test again 
        public static int AddUserAddress(string inputEmail)
        {
            PizzaBoxContex PBContex = new PizzaBoxContex();
            string address1, address2, city, state, zipcode, details;
            string inputAddressOption = null;
            int output = 0;
            int addressCount;
            int amount = 0;
            bool exitOuterWhileLoop = false;


            do
            {
                addressCount = 0;

                amount = PBContex.UserAddress.Count<UserAddress>(u => u.Email == inputEmail);
                if (amount > 0)
                {
                    var myAddresses = PBContex.UserAddress.Where<UserAddress>(u => u.Email == inputEmail);
                    Console.WriteLine("\n\nYou have the following addresses on record: \n");
                    string fullAddress = null;
                    foreach (var singleAddress in myAddresses)
                    {
                        addressCount = addressCount + 1;
                        fullAddress = singleAddress.Address1 + " " + singleAddress.Address2 + " | " + singleAddress.City + " " + singleAddress.State + " " + singleAddress.Zipcode;
                        Console.WriteLine($"[{addressCount}] {fullAddress}");
                    }
                    Console.WriteLine("\n[77] to pick up in store");
                    Console.WriteLine("[88] to add new address");
                    Console.WriteLine("[99] to exit");
                    Console.WriteLine("Where do you want to deliver your order?");
                    inputAddressOption = Console.ReadLine();
                    inputAddressOption = inputAddressOption.Trim();
                }
                else
                {
                    Console.WriteLine("You need to have at least one address in record.\n");
                }

                bool exitInnerWhileFlag = false;
                bool canConvert = long.TryParse(inputAddressOption, out Int64 result);

                do
                {
                    if (canConvert == true && Convert.ToInt32(inputAddressOption) != 0 && Convert.ToInt32(inputAddressOption) <= addressCount)
                    {
                        // one address is selected from the options 
                        exitInnerWhileFlag = true;
                        exitOuterWhileLoop = true;
                        output = Convert.ToInt32(inputAddressOption);
                    }
                    else if ("77" == inputAddressOption)
                    {
                        // to be pick up in store 
                        output = 0;
                        exitInnerWhileFlag = true;
                        exitOuterWhileLoop = true;
                    }
                    else if (0 == amount || "88" == inputAddressOption)
                    {
                        // add new address 
                        exitInnerWhileFlag = true;
                        exitOuterWhileLoop = false;

                        addressCount = addressCount + 1;
                        output = addressCount;

                        Console.Write("\nAddress 1: ");
                        address1 = Console.ReadLine();
                        address1 = address1.Trim();

                        Console.Write("\nAddress 2 [optional]: ");
                        address2 = Console.ReadLine();
                        address2 = address2.Trim();

                        Console.Write("\nCity: ");
                        city = Console.ReadLine();
                        city = city.Trim();

                        Console.Write("\nState: ");
                        state = Console.ReadLine();
                        state = state.Trim();

                        Console.Write("\nZipcode: ");
                        zipcode = Console.ReadLine();
                        zipcode = zipcode.Trim();

                        Console.Write("\nAdditional Details [optional]: ");
                        details = Console.ReadLine();
                        details = details.Trim();

                        UserAddress newUserAddress = new UserAddress();
                        newUserAddress.Email = inputEmail;
                        newUserAddress.AddressCount = addressCount;
                        newUserAddress.Address1 = address1;
                        newUserAddress.Address2 = address2;
                        newUserAddress.City = city;
                        newUserAddress.State = state;
                        newUserAddress.Zipcode = zipcode;
                        newUserAddress.AddressDetails = details;

                        PBContex.UserAddress.Add(newUserAddress);
                        PBContex.SaveChanges();
                    }
                    else if ("99" == inputAddressOption)
                    {
                        Environment.Exit(0);
                    }
                    else
                    {
                        Console.WriteLine($"\n\n\nInput is not supported. Try again.\n\n\n");
                        exitInnerWhileFlag = false;
                    }

                    if (exitInnerWhileFlag == false)
                    {
                        inputAddressOption = Console.ReadLine();
                        inputAddressOption = inputAddressOption.Trim();
                    }

                } while (exitInnerWhileFlag == false);

            } while (exitOuterWhileLoop == false);

            Console.WriteLine("Address accepted.");

            return output;

        } // end of: AddUserAddress class 

        #endregion


        #region MakeAnOrder

        public static void MakeAnOrder(int qtyInOrder, double totalInOrder)
        {

            Console.WriteLine($"\n\n\nYou already have {qtyInOrder} pizzas in your shopping cart, for a total of {totalInOrder.ToString("c2")}.");
            Thread.Sleep(5000);


            List<object> allInOrder = new List<object>();
            allInOrder = MakeAPizza(qtyInOrder, totalInOrder);

            Console.Clear();
            Console.WriteLine("\n\n\n\t\t\t***** End of Demo #0 *****");
            Console.WriteLine("\n\n\n\t\t\t***** Development In Progress *****");
            Thread.Sleep(5000);
            Environment.Exit(0);


        }

        #endregion


        #region MakeAPizza
        public static List<object> MakeAPizza(int qtyInOrder, double totalInOrder)
        {
            const int qtyLimitPerOrder = 100;
            const double priceLimitPerOrder = 5000;
            List<object> outputCollection = new List<object>();


            PizzaBoxContex PBContex = new PizzaBoxContex();
            int tempCount;
            string dictionaryInputStr;
            string strMenu = "\t\tMENU";

            #region Dictionaries

            var allSizes = PBContex.PizzaSize.OrderBy(u => u.Inches);
            strMenu = strMenu + "\n\nSizes";
            Dictionary<int, Tuple<string, double, double>> sizeDictionary = new Dictionary<int, Tuple<string, double, double>>();
            dictionaryInputStr = "";
            tempCount = 0;
            foreach (var size in allSizes)
            {
                tempCount = tempCount + 1;
                dictionaryInputStr = $"[{tempCount}]\t{size.SizeId}\t{size.Inches}-inches\t{size.SalesPrice.ToString("c2")}";
                strMenu = strMenu + "\n" + dictionaryInputStr;
                sizeDictionary.Add(tempCount, new Tuple<string, double, double>(size.SizeId, size.SalesPrice, size.ScalingFactor));
            }

            var allCrusts = PBContex.PizzaCrust.OrderBy(u => u.SalesPrice);
            strMenu = strMenu + "\n\nCrust";
            Dictionary<int, Tuple<string, double>> crustDictionary = new Dictionary<int, Tuple<string, double>>();
            dictionaryInputStr = "";
            tempCount = 0;
            foreach (var crust in allCrusts)
            {
                tempCount = tempCount + 1;
                dictionaryInputStr = $"[{tempCount}]\t{crust.CrustId}\t\t\t{crust.SalesPrice.ToString("c2")}";
                strMenu = strMenu + "\n" + dictionaryInputStr;

                crustDictionary.Add(tempCount, new Tuple<string, double>(crust.CrustId, crust.SalesPrice));
            }

            var allToppings = PBContex.PizzaTopping;
            strMenu = strMenu + "\n\nToppings";
            Dictionary<int, Tuple<string, double>> toppingDictionary = new Dictionary<int, Tuple<string, double>>();
            dictionaryInputStr = "";
            tempCount = 0;
            foreach (var topping in allToppings)
            {
                tempCount = tempCount + 1;
                if (topping.ToppingId.Length >= 8)
                {
                    dictionaryInputStr = $"[{tempCount}]\t{topping.ToppingId}\t\t{topping.SalesPrice.ToString("c2")}";
                }
                else
                {
                    dictionaryInputStr = $"[{tempCount}]\t{topping.ToppingId}\t\t\t{topping.SalesPrice.ToString("c2")}";
                }
                strMenu = strMenu + "\n" + dictionaryInputStr;

                toppingDictionary.Add(tempCount, new Tuple<string, double>(topping.ToppingId, topping.SalesPrice));
            }

            strMenu = strMenu + "\n\n";

            #endregion

            List<string> headersList = new List<string> { "Size:", "Crust:", "Topping #1:", "Topping #2:", "Topping #3:", "Topping #4:", "Topping #5:" };
            List<string> pizzaSCT5_Id = new List<string>();
            List<double> pizzaSCT5_Prices = new List<double>();

            bool exitWhileFlag;
            string userInput;
            int toppingCount;
            int lastKey;
            bool inputIsNumeric;
            int inputValue;


            #region ChooseSize

            Console.Clear();
            Console.WriteLine(strMenu);
            userInput = "";
            lastKey = sizeDictionary.Keys.Last();
            exitWhileFlag = false;
            inputIsNumeric = false;
            inputValue = 0;
            do
            {
                Console.Write("\n\n\nChoose a Size: ");
                userInput = Console.ReadLine();
                userInput = userInput.Trim();
                inputIsNumeric = long.TryParse(userInput, out Int64 result);

                if (inputIsNumeric)
                {
                    inputValue = Convert.ToInt32(userInput);
                }

                if (inputIsNumeric && inputValue > 0 && inputValue <= lastKey)
                {
                    pizzaSCT5_Id.Add(sizeDictionary[inputValue].Item1);
                    pizzaSCT5_Prices.Add(sizeDictionary[inputValue].Item2);
                    exitWhileFlag = true;
                }
                else
                {
                    Console.WriteLine("Input not supported. Try again.");
                    exitWhileFlag = false;
                }

            } while (exitWhileFlag == false);


            #endregion


            #region ChooseCrust

            Console.Clear();
            Console.WriteLine(strMenu);
            Console.WriteLine("\n\nCurrent selections:");
            PrintPizza(headersList, pizzaSCT5_Id, pizzaSCT5_Prices);
            userInput = "";
            lastKey = crustDictionary.Keys.Last();
            exitWhileFlag = false;
            inputIsNumeric = false;
            inputValue = 0;
            do
            {
                Console.Write("\n\n\nChoose a Crust: ");
                userInput = Console.ReadLine();
                userInput = userInput.Trim();
                inputIsNumeric = long.TryParse(userInput, out Int64 result);

                if (inputIsNumeric)
                {
                    inputValue = Convert.ToInt32(userInput);
                }

                if (inputIsNumeric && inputValue > 0 && inputValue <= lastKey)
                {
                    pizzaSCT5_Id.Add(crustDictionary[inputValue].Item1);
                    pizzaSCT5_Prices.Add(crustDictionary[inputValue].Item2);
                    exitWhileFlag = true;
                }
                else
                {
                    Console.WriteLine("Input not supported. Try again.");
                    exitWhileFlag = false;
                }

            } while (exitWhileFlag == false);

            #endregion


            #region ChooseToppings

            Console.Clear();
            Console.WriteLine(strMenu);
            Console.WriteLine("\n\nCurrent selections:");
            PrintPizza(headersList, pizzaSCT5_Id, pizzaSCT5_Prices);
            userInput = "";
            lastKey = toppingDictionary.Keys.Last();
            exitWhileFlag = false;
            inputIsNumeric = false;
            inputValue = 0;
            toppingCount = 1;
            Console.WriteLine("\n\nChoose up to 5 toppings. To finish choosing toppings enter [99].");
            do
            {
                if (toppingCount <= 5)
                {
                    Console.Write($"Topping #{toppingCount}: ");
                    userInput = Console.ReadLine();
                    userInput = userInput.Trim();
                    inputIsNumeric = long.TryParse(userInput, out Int64 result);

                    if (inputIsNumeric)
                    {
                        inputValue = Convert.ToInt32(userInput);
                    }

                    if (inputIsNumeric && inputValue > 0 && inputValue <= lastKey)
                    {
                        pizzaSCT5_Id.Add(toppingDictionary[inputValue].Item1);
                        pizzaSCT5_Prices.Add(toppingDictionary[inputValue].Item2);
                    }
                    else if (99 == inputValue)
                    {
                        exitWhileFlag = true;
                    }
                    else
                    {
                        Console.WriteLine("Input not supported. Try again.");
                        toppingCount = toppingCount - 1;
                        exitWhileFlag = false;
                    }
                    toppingCount = toppingCount + 1;
                }
                else
                {
                    exitWhileFlag = true;
                }
            } while (exitWhileFlag == false);

            #endregion


            #region QtyPerOrder 

            Console.Clear();
            Console.WriteLine("\n\nCurrent selections:");
            PrintPizza(headersList, pizzaSCT5_Id, pizzaSCT5_Prices);
            exitWhileFlag = false;
            inputIsNumeric = false;
            userInput = "";
            inputValue = 0;
            Console.WriteLine("You can order up to {0} of the above pizza.", qtyLimitPerOrder - qtyInOrder);

            // --------> need to add constraint with Price limit taking in consideration the price of the pizza in progress 

            do
            {
                Console.Write("\nHow many do you want? ");
                userInput = Console.ReadLine();
                inputIsNumeric = long.TryParse(userInput, out Int64 result);

                if (inputIsNumeric)
                {
                    inputValue = Convert.ToInt32(userInput);
                }

                if (inputIsNumeric && inputValue <= (qtyLimitPerOrder - qtyInOrder))
                {
                    qtyInOrder = qtyInOrder + inputValue;
                    exitWhileFlag = true;
                }
                else
                {
                    Console.WriteLine("Input not supported. Try again.");
                    exitWhileFlag = false;
                }

            } while (exitWhileFlag == false);

            double subTotal2 = 0;
            foreach (double x in pizzaSCT5_Prices)
            {
                subTotal2 = subTotal2 + x;
            }
            subTotal2 = subTotal2 * inputValue;
            totalInOrder = subTotal2 + totalInOrder;

            Console.Clear();
            Console.WriteLine("\n\nFrom the last selection:");
            PrintPizza(headersList, pizzaSCT5_Id, pizzaSCT5_Prices);
            Console.WriteLine(String.Format("{0,-15}  {1,-15}  {2,3}", "Sub-Quantity", "", inputValue.ToString()));
            Console.WriteLine(String.Format("{0,-15}  {1,-15}  {2,5}", "", "", "___________"));
            Console.WriteLine(String.Format("{0,-15}  {1,-15}  {2,5}", "Sub-Total #2", "", subTotal2.ToString("c2")));
            Console.WriteLine("");
            Console.WriteLine(String.Format("{0,-15}  {1,-15}  {2,3}", "Total-Quantity", "", qtyInOrder.ToString()));
            Console.WriteLine("");
            Console.WriteLine(String.Format("{0,-15}  {1,-15}  {2,5}", "Total", "", totalInOrder.ToString("c2")));

            #endregion

            //   -------------> move to MakeAnOrder method  


            #region OrderMore 

            bool orderMore;
            orderMore = false;
            if ((qtyInOrder < qtyLimitPerOrder) && (totalInOrder < priceLimitPerOrder))
            {
                Console.WriteLine("\n\n\nYou can order up to {0} new pizzas in this order?", qtyLimitPerOrder - qtyInOrder);
                Console.WriteLine("\nWould you like to add more pizzas to this order? ");
                Console.WriteLine("[1] Yes \n[2] No");

                exitWhileFlag = false;
                inputIsNumeric = false;
                userInput = "";
                inputValue = 0;

                do
                {
                    Console.Write("\nAdd more: ");
                    userInput = Console.ReadLine();
                    inputIsNumeric = long.TryParse(userInput, out Int64 result);

                    if (inputIsNumeric)
                    {
                        inputValue = Convert.ToInt32(userInput);
                    }

                    if (inputIsNumeric && inputValue == 1)
                    {
                        exitWhileFlag = true;
                        orderMore = true;
                    }
                    else if (inputIsNumeric && inputValue == 2)
                    {
                        exitWhileFlag = true;
                        orderMore = false;
                    }
                    else
                    {
                        Console.WriteLine("Input not supported. Try again.");
                        exitWhileFlag = false;
                    }

                } while (exitWhileFlag == false);

            }

            #endregion



            outputCollection.Add(headersList);
            outputCollection.Add(pizzaSCT5_Id);
            outputCollection.Add(pizzaSCT5_Prices);
            outputCollection.Add(qtyInOrder);
            outputCollection.Add(totalInOrder);

            return outputCollection;


        } // end of: MakeAPizza method

        #endregion


        #region PrintMethods

        public static void PrintPizza(List<string> headerList, List<string> itemList, List<double> priceList)
        {
            int listLength = itemList.Count;

            double subTotal = 0;
            for (int i = 0; i < listLength; i++)
            {
                Console.WriteLine(String.Format("{0,-15}  {1,-15}  {2,5}", headerList[i], itemList[i], priceList[i].ToString("c2")));
                subTotal = subTotal + priceList[i];
            }
            Console.WriteLine(String.Format("{0,-15}  {1,-15}  {2,5}", "", "", "___________"));
            Console.WriteLine(String.Format("{0,-15}  {1,-15}  {2,5}", "Sub-Total #1", "", subTotal.ToString("c2")));
        } // end of: PrintPizza method


        #endregion



    } // end of: ClassDomain 
} // end of: Domain namespace 