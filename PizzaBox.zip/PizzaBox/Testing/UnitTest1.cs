
// do a test for each method 
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Testing
{
    [TestClass]
    public class UnitTest1
    {
        public string myStr = "this is UnitTest1";

        [TestMethod]
        public void TestMethod1()
        {
            System.Console.WriteLine("this is TestMethod1 in UnitTest1 class");
        }
    }
}
