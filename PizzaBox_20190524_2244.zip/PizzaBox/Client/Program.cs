﻿// Client or Presentation or UI layer 

using System;
using Data;
using System.Collections.Generic;

using Domain;
using Testing;
using Data.DataModel;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using System.Linq;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;



namespace Client
{
    class Program
    {
        static void Main(string[] args)
        {

            // NOTE TO-EDIT: add main menu 

            string email = GrantAccess.Welcome();
            int storeLocation = Locations.SelectLocation();
            List<object> fullOrder = new List<object>();

            bool canMakeAnOrder = DateTimeCheck.CheckIfCanOrder(email, storeLocation);
            if (canMakeAnOrder)
            {
                fullOrder = Order.MakeAnOrder();
            }
            else
            {
                Environment.Exit(0);
                // NOTE TO-EDIT: Add options to go back to main menu or exit application 
            }

            Checkout.ConfirmOrder(email, storeLocation, fullOrder);

            Console.WriteLine("\n\n\n");
            Console.WriteLine("\t\t\tOrder placed successfully.");
            Console.WriteLine("\t\t\tSee you soon.");
            Console.WriteLine("\n\n\n\t\t\tSign-Out\n\n\n");


        } // end of: Main class 
    } // end of: Program class 
} // end of: Client namespace 