﻿// Data layer 
using System;

namespace Data
{
    public class ClassData
    {

      
             
    }
}
