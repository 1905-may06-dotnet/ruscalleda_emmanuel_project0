﻿using System;
using System.Collections.Generic;

namespace Data.DataModel
{
    public partial class IngredientMinMax
    {
        public IngredientMinMax()
        {
            LocationInventory = new HashSet<LocationInventory>();
            PizzaTopping = new HashSet<PizzaTopping>();
        }

        public string IngredientId { get; set; }
        public int MinLevel { get; set; }
        public int MaxLevel { get; set; }

        public virtual ICollection<LocationInventory> LocationInventory { get; set; }
        public virtual ICollection<PizzaTopping> PizzaTopping { get; set; }
    }
}
