﻿using System;
using System.Collections.Generic;

namespace Data.DataModel
{
    public partial class LocationInventory
    {
        public int LocationId { get; set; }
        public string IngredientId { get; set; }
        public int CurrentLevel { get; set; }

        public virtual IngredientMinMax Ingredient { get; set; }
        public virtual LocationAddress Location { get; set; }
    }
}
