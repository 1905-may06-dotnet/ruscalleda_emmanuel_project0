﻿using System;
using System.Collections.Generic;

namespace Data.DataModel
{
    public partial class PizzaTopping
    {
        public PizzaTopping()
        {
            OrderTopping = new HashSet<OrderTopping>();
        }

        public string ToppingId { get; set; }
        public float SalesPrice { get; set; }
        public string IngredientId { get; set; }

        public virtual IngredientMinMax Ingredient { get; set; }
        public virtual ICollection<OrderTopping> OrderTopping { get; set; }
    }
}
