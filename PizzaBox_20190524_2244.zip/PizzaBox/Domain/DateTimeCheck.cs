﻿using System;
using System.Collections.Generic;
using System.Text;
using Data.DataModel;
using Data; 
using System.Linq;


namespace Domain
{
    public class DateTimeCheck
    {
        public static bool CheckIfCanOrder(string emailInput, int selectedLocation)
        {
            const int hoursConstraintsBetweenOrders = 2;
            const int daysConstraintsBetweenOrders = 1;
            bool canMakeAnOrder = false; // output 

            PizzaBoxContex PBContex = DbInstance.Instance;
            try
            {
                var x = PBContex.OrderSummary.Where<OrderSummary>(u => u.Email == emailInput).Last<OrderSummary>();
                var y = PBContex.LocationAddress.Where<LocationAddress>(u => u.LocationId == selectedLocation).First<LocationAddress>();
                int lastLocaiton = x.LocationId;
                string lastOrderDate = x.Date;
                string lastOrderTime = x.Time;
                string fullAddress = "\t" + y.Nickname + "\n\t" + y.Address1 + " " + y.Address2 + "\n\t" + y.City + " " + y.State + " " + y.Zipcode;

                DateTime nowIs = DateTime.Now;
                string lastOrderDateTimeStr = lastOrderDate + " " + lastOrderTime;
                DateTime lastOrderDateTime = Convert.ToDateTime(lastOrderDateTimeStr);
                DateTime lastOrderDateTimePlus2hr = lastOrderDateTime.AddHours(hoursConstraintsBetweenOrders);
                DateTime lastOrderDateTimePlus1day = lastOrderDateTime.AddDays(daysConstraintsBetweenOrders);
                int compareDate = DateTime.Compare(nowIs, lastOrderDateTimePlus1day); // compareDate = 1 if nowIs > lastOrderDateTimePlus1day
                int compareTime = DateTime.Compare(nowIs, lastOrderDateTimePlus2hr); // compareTime = 1 if nowIs > lastOrderDateTimePlus2hr

                if (selectedLocation == lastLocaiton)
                {
                    if (compareDate == 1 && compareTime == 1)
                    {
                        canMakeAnOrder = true;
                    }
                    else
                    {
                        Console.WriteLine($"Your last order was on {lastOrderDateTime.ToString("   MMM dd, yyyy   hh:mm tt")}.");
                        Console.WriteLine("You have to wait at least 1-day to order from ");
                        Console.WriteLine($"\n{fullAddress}\n");
                        if (compareTime != 1)
                        {
                            Console.WriteLine("and you have to wait at least 2-hrs after your last order to order from any other store.");
                        }
                        Console.WriteLine($"You can order again from the selected location on {lastOrderDateTimePlus1day.ToString("MMM dd, yyyy")}.");
                        if (compareTime == 1)
                        {
                            Console.WriteLine("You can order from any other store right now.");
                        }
                    }
                }
                else
                {
                    // selectedLocation is not the same as lastLocation 
                    if (compareTime == 1)
                    {
                        canMakeAnOrder = true;
                    }
                    else
                    {
                        Console.WriteLine($"Your last order was on {lastOrderDateTime.ToString("   MMM dd, yyyy   hh:mm tt")}.");
                        Console.WriteLine("You have to wait at least 2-hrs after your last order.");
                        Console.WriteLine($"You can order again after {lastOrderDateTimePlus2hr.ToString("hh:mm tt")}.");
                    }
                }
            }
            catch
            {
                canMakeAnOrder = true; 
            }

            return canMakeAnOrder;

        } // end of: CheckIfCanOrder method 
    } // end of: DateTimeCheck class
}