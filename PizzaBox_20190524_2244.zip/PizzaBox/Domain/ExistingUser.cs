﻿using System;
using System.Collections.Generic;
using System.Text;
using Data.DataModel;
using System.Linq;
using Data;
using System.Threading;



namespace Domain
{
    public class ExistingUser
    {
        public static List<string> SignIn()
        {
            PizzaBoxContex PBContex = DbInstance.Instance;
            List<string> output = new List<string>();
            string emailInput = "";
            string passwordInput = "";
            bool exitWhile;

            // ask for email 
            do
            {
                exitWhile = true;
                Console.Write("Email: \t");
                emailInput = Console.ReadLine().Trim();

                // check if input email is on database 
                try
                {
                    var x = PBContex.UserName.Where<UserName>(u => u.Email == emailInput).First<UserName>();
                    output.Add(x.Email);
                    output.Add(x.FirstName); 
                }
                catch
                {
                    if (emailInput.Equals("99"))
                    {
                        Environment.Exit(0);
                    }
                    Console.WriteLine("\n\n\nUser not found. Try again. \nTo exit enter [99]. \n\n\n");
                    exitWhile = false;
                }
            } while (exitWhile == false);


            // ask for password 
            int passwordAttempts = 0;
            do
            {
                exitWhile = true;
                Console.Write("PizzaBox Password: \t");
                passwordInput = Console.ReadLine().Trim();
                // check if password match email  
                try
                {
                    PBContex.UserAccess.Where<UserAccess>(u => u.Email == emailInput && u.Password == passwordInput).First<UserAccess>();
                }
                catch
                {
                    if (passwordInput.Equals("99"))
                    {
                        Environment.Exit(0);
                    }
                    Console.WriteLine("\n\n\nIncorrect password. Try again. \nTo exit enter [99]. \n\n\n");
                    passwordAttempts = passwordAttempts + 1;
                    if (passwordAttempts >= 3)
                    {
                        Console.WriteLine("Exceeded the allowed attempts.");
                        Environment.Exit(0);
                    }
                    exitWhile = false;
                }
            } while (exitWhile == false);

            Console.WriteLine("\n\n\nSign-In successful! \n\n\n");
            Thread.Sleep(2000);


            return output;

        } // end of: SignIn method 
    } // end of: ExistingUser class 
}
