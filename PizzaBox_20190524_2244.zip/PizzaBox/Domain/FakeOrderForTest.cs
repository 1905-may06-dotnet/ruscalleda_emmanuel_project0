﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain
{
    public class FakeOrderForTest
    {
        public static List<object> FlaseData()
        {
            List<object> output; 
            List<string> headersList = new List<string> { "Size:", "Crust:", "Topping #1:", "Topping #2:", "Topping #3:", "Topping #4:", "Topping #5:" };

            List<string> pizzaSCT5_Id_1 = new List<string>();
            pizzaSCT5_Id_1.Add("small");
            pizzaSCT5_Id_1.Add("regular");

            List<double> pizzaSCT5_Prices_1 = new List<double>();
            pizzaSCT5_Prices_1.Add(8.99);
            pizzaSCT5_Prices_1.Add(0.00);

            List<string> pizzaSCT5_Id_2 = new List<string>();
            pizzaSCT5_Id_2.Add("large");
            pizzaSCT5_Id_2.Add("regular");
            pizzaSCT5_Id_2.Add("onion");

            List<double> pizzaSCT5_Prices_2 = new List<double>();
            pizzaSCT5_Prices_2.Add(12.99);
            pizzaSCT5_Prices_2.Add(0.00);
            pizzaSCT5_Prices_2.Add(1.00);

            List<object> allLineItemsId = new List<object>();
            allLineItemsId.Add(pizzaSCT5_Id_1);
            allLineItemsId.Add(pizzaSCT5_Id_2);

            List<object> allLineItemsPrice = new List<object>();
            allLineItemsPrice.Add(pizzaSCT5_Prices_1);
            allLineItemsPrice.Add(pizzaSCT5_Prices_2);

            List<int> qtyPerLine = new List<int>();
            qtyPerLine.Add(2);
            qtyPerLine.Add(3);

            List<int> linesPerOrder = new List<int>();
            linesPerOrder.Add(1);
            linesPerOrder.Add(2);

            List<object> fullOrder = new List<object>();
            fullOrder.Add(headersList);
            fullOrder.Add(allLineItemsId);
            fullOrder.Add(allLineItemsPrice);
            fullOrder.Add(qtyPerLine);
            fullOrder.Add(linesPerOrder);

            output = fullOrder;
            return output; 

        }
    }
}
