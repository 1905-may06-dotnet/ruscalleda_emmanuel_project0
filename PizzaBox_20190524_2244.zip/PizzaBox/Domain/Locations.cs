﻿using System;
using System.Collections.Generic;
using System.Text;
using Data;
using Data.DataModel;
using System.Linq;
using System.Threading;



namespace Domain
{
    public class Locations
    {

        public static int SelectLocation()
        {
            PizzaBoxContex PBContex = DbInstance.Instance;
            var allLocations = PBContex.LocationAddress;
            int maxID = PBContex.LocationAddress.Max<LocationAddress>(p => p.LocationId);
            string fullAddress;
            int output = 0; 

            Console.WriteLine("The following locations are available: \n\n");

            foreach (var y in allLocations)
            {
                fullAddress = "[" + y.LocationId + "]" + "\t" + y.Nickname + "\n\t" + y.Address1 + " " + y.Address2 + "\n\t" + y.City + " " + y.State + " " + y.Zipcode + "\n\t" + y.Phone + "\n\n";
                Console.WriteLine(fullAddress);
            }

            string userInput;
            int inputValue = 0;
            bool inputIsNumeric;
            bool exitWhile = false;

            do
            {
                Console.Write("\n\n\nChoose a location: ");
                userInput = Console.ReadLine().Trim();
                inputIsNumeric = long.TryParse(userInput, out Int64 result);

                if (inputIsNumeric)
                {
                    inputValue = Convert.ToInt32(userInput);
                }


                if (inputIsNumeric && (inputValue > 0) && (inputValue <= maxID))
                {
                    exitWhile = true;
                    output = inputValue; 
                }
                else if ("99" == userInput)
                {
                    Environment.Exit(0);
                }
                else
                {
                    Console.WriteLine("Input not supported. Try again. To exit application [99]");
                    exitWhile = false;
                }

            } while (exitWhile == false);


            // NOTE TO-EDIT: add a better confirmation message: clear screen and show selection 
            Console.WriteLine($"\n\n\nLocation [{inputValue}] accepted.\n\n\n");
            Thread.Sleep(2000);
            Console.Clear();

            return output; 

        } // end of: SelectLocation method 
    } // end of: Locations class
}
